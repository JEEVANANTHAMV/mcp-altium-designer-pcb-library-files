---
name: altium-library
display_name: "Altium Library MCP (34 tools, offline native parser)"
description: "Read and write Altium Designer component libraries (.PcbLib, .SchLib, .PcbPkg) using a Rust binary that parses the formats in-process — no Altium install required. 34 stdio tools: read/write/search/validate/diff/merge/export/repair component libraries, manage symbols and footprints, extract Step models, render, batch update, and backup/restore. Altium is only needed to open the edited files afterward. Use when an engineer or agent needs to mutate an Altium library offline, batch-rename components, compare libraries, repair a corrupt lib, or generate a BOM/footprint summary."
---

# Altium Library MCP - effective-use skill

A Rust MCP server that edits **Altium Designer** libraries **in-process**,
with no Altium application required for the server to run.

## Server binary
`altium-designer-mcp.exe` is a static Rust binary. It speaks MCP over stdio.

## Invocation (mcp.json)
    command : altium-designer-mcp.exe
    args    : [ <INSTALL_DIR>/mcp-config.json ]        # or:  --allow <dir>...
    env     : RUST_LOG=info

- Config file path can be any of:
  * `mcp-config.json` (shipped, edit it to whitelist your library dirs);
  * `--allow DIR` flags (repeatable) to add to / replace the allow list.

Security contract: the server **only** touches files under `allowed_paths`
from the config (plus any `--allow` args). It keeps per-library backups in a
`backups/` subfolder (see `list_backups` / `restore_backup`).

## Tool families (34 total)
    read     read_pcblib    read_schlib    list_components    extract_style
    write    write_pcblib   write_schlib   write_libpkg       delete_component
    validate validate_library
    export   export_library import_library extract_step_model
    diff     diff_libraries compare_components
    batch    batch_update   bulk_rename    reorder_components
    mutate   update_component  update_pad  update_primitive
    copy     copy_component   copy_component_cross_library   merge_libraries
    render   render_footprint render_symbol
    params   manage_schlib_parameters   manage_schlib_footprints
    repair   repair_library
    backup   list_backups   restore_backup
    inspect  search_components  get_component  component_exists

## Common recipes
- **Add / replace a footprint in a `.PcbLib`**:
  1. `read_pcblib` (path) to enumerate current components.
  2. `extract_step_model` if the source is STEP.
  3. `write_pcblib` (path, component-spec JSON) to write the update.
  4. `list_backups` to confirm the pre-edit copy is present.
- **Rename a set of components across a family**: `bulk_rename` in a single tool call.
- **Diff two libraries**: `diff_libraries` (libA, libB) returns added/removed/changed.
- **Recover an old version**: `list_backups` then `restore_backup`.

## Config file (mcp-config.json)
    allowed_paths : list of dirs the server may read/write.
    logging       : level + optional `audit_log_path` (writes an append-only audit trail).
    rate_limit    : per-client token bucket (default 120 burst / 30 ref/s).
    ansi_code_page: Windows ANSI code page used when writing new footprint names
                    (936 = GBK, 1250/1252 = Western/Central Europe; null = default).

## Altium is NOT required at runtime
The binary parses the binary `.PcbLib`/`.SchLib` formats. Altium is only
required **afterward** to open the edited files in the GUI. The
`render_footprint` / `render_symbol` tools render to PNG in-memory so you can
preview without Altium.

## Verification (offline, at build time)
`altium-designer-mcp.exe --help` -> prints usage.
MCP probe with a config file: `initialize` -> ok, `tools/list` -> **34 tools**.
