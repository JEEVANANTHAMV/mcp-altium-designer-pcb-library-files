# Altium Designer MCP Server (offline, native binary)

A **Rust** MCP server that reads and writes
**Altium** component libraries (`.PcbLib`, `.SchLib`, `.PcbPkg`, `.PcbDoc`
footprints, etc.) **without the Altium application**. It parses the binary
library formats directly. The Altium app is only needed *afterwards* to open
the modified files in the GUI.

* **Server:** `altium-designer-mcp.exe` (single static binary; stdio by default).
* **Transport:** stdio (MCP). Also offers `--http <addr>` for
  Streamable-HTTP if you want a long-running endpoint.
* **Tools:** 34 (read/write/search/validate/diff/merge/export/repair of
  component libraries; symbol & footprint ops; Step-model extraction;
  render & back-fill; batch operations; backup/restore).
* **Config:** `mcp-config.json` (shipped next to the exe). `allowed_paths`
  must list **only the directories you want the server to touch** (security
  boundary) - keep it as narrow as possible.

## Layout
    altium-designer-mcp.exe  the server binary (~11 MB)
    mcp-config.json          shipped config; set allowed_paths to your libs
    UPSTREAM-README.md       original project README (kept for reference)
    example-config.json      example config (from the release zip)

## How to use
1. Put your Altium library files (`.PcbLib`, `.SchLib`, ...) in a folder.
   **Do not** point this at a read-only source-of-truth without a backup path.
2. Edit `mcp-config.json`:
       "allowed_paths": [ "C:/Users/you/Altium/MyLibraries" ]
   (forward slashes or escaped backslashes are fine on Windows.)
3. The server edits library files **in place**; it keeps its own backups in a
   per-library `backups/` folder and can restore them via the
   `list_backups` / `restore_backup` tools.
4. To open the modified libraries, use Altium's own GUI.

## Tools (34 total)
    read_pcblib / read_schlib / list_components / extract_style
    write_pcblib / write_schlib / write_libpkg / delete_component
    validate_library / export_library / import_library / extract_step_model
    diff_libraries / batch_update / copy_component / rename_component
    copy_component_cross_library / merge_libraries / reorder_components
    update_component / search_components / get_component / component_exists
    render_footprint / render_symbol
    manage_schlib_parameters / manage_schlib_footprints
    compare_components / repair_library
    list_backups / restore_backup / bulk_rename / update_pad / update_primitive

## env variables
    RUST_LOG     (optional) info | debug | warn | error | trace
    (there is **no** separate auth; the config file is the only control.)

## mcp.json (as bundled)
    {
      "command": "__INSTALL_DIR__\\altium-designer-mcp.exe",
      "args":    ["__INSTALL_DIR__\\mcp-config.json"],
      "env":     { "RUST_LOG": "info" }
    }

If you do NOT want to bind to a config file, pass the allowed directories
explicitly to the binary instead (e.g. `altium-designer-mcp.exe --allow C:\libs`).
This is often friendlier for a multi-machine deploy: `--allow` merges with any
config and requires no file on disk.

## Test (offline)
With a config file that includes some library dirs, the probe used at build
time: `initialize` -> ok, `tools/list` -> **34 tools**.
`altium-designer-mcp.exe --help` prints usage (no network needed).
